const toggleBtn = document.getElementById('toggleToolbar');
const recordBtn = document.getElementById('startRecord');
const settingsBtn = document.getElementById('openSettings');

toggleBtn.addEventListener('click', async () => {
  const res = await chrome.runtime.sendMessage({ type: 'POPUP_TOGGLE_TOOLBAR' });
  if (!res?.ok) {
    showError('このページでは動作しません（chrome://、Chromeウェブストア等）');
    return;
  }
  window.close();
});

recordBtn.addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'POPUP_OPEN_RECORDER' });
  window.close();
});

settingsBtn.addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

function showError(msg) {
  let el = document.getElementById('popupError');
  if (!el) {
    el = document.createElement('div');
    el.id = 'popupError';
    el.style.cssText = 'margin:0 14px 12px;padding:8px 12px;background:rgba(203,84,87,0.1);border:1.5px solid rgba(203,84,87,0.3);border-radius:10px;color:#CB5457;font-size:11px;font-weight:700;';
    document.querySelector('.app').insertBefore(el, document.querySelector('.footer'));
  }
  el.textContent = msg;
}
