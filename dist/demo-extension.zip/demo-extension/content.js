// Demo Pointer Pro — content script
// オーバーレイUI + 全ツールの実装

(function () {
  if (window.__DEMO_EXT_INITED__) return;
  window.__DEMO_EXT_INITED__ = true;

  const PALETTE = globalThis.DEMO_EXT_PALETTE;
  const THEME = globalThis.DEMO_EXT_THEME;
  const STAMPS = globalThis.DEMO_EXT_STAMPS;
  const EMOJIS = globalThis.DEMO_EXT_EMOJIS;

  // ──────────── 状態管理 ────────────
  const state = {
    enabled: false,
    tool: 'pointer',         // pointer/rect/circle/arrow/pen/text/eraser/mosaic/spotlight/magnifier/keystroke/step/stamp/emoji
    color: THEME.accent,
    strokeWidth: 4,
    stepCounter: 1,
    selectedStamp: STAMPS[0],
    selectedEmoji: EMOJIS[0],
    spotlightOn: false,
    magnifierOn: false,
    keystrokeOn: false,
    pikonOn: true,           // クリック視覚化はデフォルトON
  };

  let host, shadow, toolbar, svgOverlay, htmlOverlay, spotlightEl, magnifierEl, keystrokeEl;

  // ──────────── メッセージ受信 ────────────
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'TOGGLE_TOOLBAR') toggleToolbar();
    // 録画はrecorder.html側で処理する（user gesture保持のため）
  });

  // ──────────── トグル ────────────
  function toggleToolbar() {
    if (!host) initUI();
    state.enabled = !state.enabled;
    host.style.display = state.enabled ? 'block' : 'none';
    if (!state.enabled) {
      setTool('pointer');
      setSpotlight(false);
      setMagnifier(false);
      setKeystroke(false);
    }
  }

  // ──────────── UI 初期化 ────────────
  function initUI() {
    host = document.createElement('div');
    host.id = '__demo_ext_host__';
    host.style.cssText = 'position:fixed;inset:0;z-index:2147483646;pointer-events:none;display:none;';
    document.documentElement.appendChild(host);

    shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = TEMPLATE;

    toolbar = shadow.getElementById('toolbar');
    svgOverlay = shadow.getElementById('svgOverlay');
    htmlOverlay = shadow.getElementById('htmlOverlay');
    spotlightEl = shadow.getElementById('spotlight');
    magnifierEl = shadow.getElementById('magnifier');
    keystrokeEl = shadow.getElementById('keystroke');

    bindToolbar();
    bindDrawing();
    bindClickEffect();
    bindKeystroke();
    bindMagnifier();
    bindSpotlight();
    renderColorPalette();
    renderStampPanel();
    renderEmojiPanel();
    makeDraggable(toolbar, shadow.getElementById('dragHandle'));
  }

  // ──────────── ツールバーUIテンプレート ────────────
  const TEMPLATE = `
    <style>
      @import url('https://fonts.googleapis.com/css2?family=M+PLUS+Rounded+1c:wght@500;700;900&display=swap');
      :host { all: initial; }
      * { box-sizing: border-box; font-family: 'M PLUS Rounded 1c', sans-serif; }

      #svgOverlay, #htmlOverlay {
        position: fixed; inset: 0; pointer-events: none;
      }
      #svgOverlay { z-index: 2147483640; }
      #htmlOverlay { z-index: 2147483641; }

      .drawing #svgOverlay { pointer-events: auto; cursor: crosshair; }
      .stamping #svgOverlay { pointer-events: auto; cursor: copy; }
      .erasing #svgOverlay { pointer-events: auto; cursor: not-allowed; }

      #spotlight {
        position: fixed; inset: 0; pointer-events: none;
        background: radial-gradient(circle 120px at var(--mx,50%) var(--my,50%),
                    rgba(0,0,0,0) 0%, rgba(0,0,0,0) 80px, rgba(0,0,0,0.7) 200px);
        z-index: 2147483639; display: none;
      }
      #spotlight.on { display: block; }

      #magnifier {
        position: fixed; width: 180px; height: 180px; border-radius: 50%;
        border: 4px solid #FFD93D; box-shadow: 0 6px 24px rgba(0,0,0,0.3);
        pointer-events: none; z-index: 2147483642; display: none;
        overflow: hidden; background: #fff;
      }
      #magnifier.on { display: block; }
      #magnifier canvas { width: 100%; height: 100%; }

      #keystroke {
        position: fixed; bottom: 32px; left: 50%; transform: translateX(-50%);
        display: none; gap: 6px; z-index: 2147483645; pointer-events: none;
      }
      #keystroke.on { display: flex; }
      .key-chip {
        background: rgba(38,39,36,0.92); color: #FFD93D;
        padding: 10px 16px; border-radius: 10px; font-weight: 900; font-size: 18px;
        border: 2px solid #FFD93D; box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        animation: keyPop 0.3s ease;
      }
      @keyframes keyPop {
        0% { transform: scale(0.6); opacity: 0; }
        100% { transform: scale(1); opacity: 1; }
      }

      /* ── ツールバー本体 ── */
      #toolbar {
        position: fixed; top: 20px; left: 20px;
        background: ${THEME.base};
        border: 2px solid ${THEME.accent};
        border-radius: 18px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.18);
        padding: 8px; pointer-events: auto;
        z-index: 2147483647;
        display: flex; flex-direction: column; gap: 6px;
        min-width: 56px;
      }
      #dragHandle {
        height: 12px; cursor: grab;
        background: repeating-linear-gradient(90deg,
          ${THEME.accent} 0 4px, transparent 4px 8px);
        border-radius: 6px; opacity: 0.5;
      }
      #dragHandle:active { cursor: grabbing; }

      .tool-row { display: flex; gap: 4px; flex-wrap: wrap; }
      .tool-btn {
        width: 40px; height: 40px;
        background: #fff;
        border: 1.5px solid rgba(166,181,165,0.3);
        border-radius: 10px; cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        font-size: 18px; transition: all 0.15s;
        position: relative;
      }
      .tool-btn:hover {
        border-color: ${THEME.accent};
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
      }
      .tool-btn.active {
        background: ${THEME.accent};
        border-color: ${THEME.accent};
        color: #fff;
        box-shadow: 0 3px 10px rgba(166,181,165,0.4);
      }
      .tool-btn.recording {
        background: #CB5457;
        border-color: #CB5457;
        color: #fff;
        animation: recPulse 1.2s infinite;
      }
      @keyframes recPulse {
        0%,100% { box-shadow: 0 0 0 0 rgba(203,84,87,0.6); }
        50% { box-shadow: 0 0 0 8px rgba(203,84,87,0); }
      }

      .divider {
        height: 1px; background: rgba(166,181,165,0.25); margin: 4px 2px;
      }

      .panel {
        position: absolute; left: 64px; top: 0;
        background: ${THEME.base};
        border: 2px solid ${THEME.accent};
        border-radius: 14px; padding: 10px;
        box-shadow: 0 8px 24px rgba(0,0,0,0.15);
        display: none; min-width: 220px; max-width: 280px;
      }
      .panel.open { display: block; }
      .panel-title {
        font-size: 11px; font-weight: 900; color: ${THEME.text};
        opacity: 0.6; letter-spacing: 1px; margin-bottom: 8px; text-transform: uppercase;
      }

      /* カラーパレット */
      #colorPanel .swatches {
        display: grid; grid-template-columns: repeat(10, 18px); gap: 4px;
      }
      .swatch {
        width: 18px; height: 18px; border-radius: 5px; cursor: pointer;
        border: 2px solid transparent; transition: transform 0.1s;
      }
      .swatch:hover { transform: scale(1.2); }
      .swatch.active { border-color: ${THEME.text}; }

      .stroke-row { display: flex; gap: 4px; margin-top: 8px; align-items: center; }
      .stroke-btn {
        width: 28px; height: 24px; border-radius: 6px; cursor: pointer;
        border: 1.5px solid rgba(166,181,165,0.3); background: #fff;
        display: flex; align-items: center; justify-content: center;
      }
      .stroke-btn.active { border-color: ${THEME.accent}; background: rgba(166,181,165,0.15); }
      .stroke-dot { background: ${THEME.text}; border-radius: 50%; }

      /* スタンプパネル */
      #stampPanel .stamp-list {
        display: grid; grid-template-columns: repeat(2, 1fr); gap: 6px;
      }
      .stamp-chip {
        padding: 8px 10px; border-radius: 10px; cursor: pointer;
        font-weight: 900; font-size: 13px; text-align: center;
        border: 2px solid transparent; transition: transform 0.1s;
      }
      .stamp-chip:hover { transform: translateY(-2px); }
      .stamp-chip.active { box-shadow: 0 0 0 3px ${THEME.text}; }

      /* 絵文字パネル */
      #emojiPanel .emoji-list {
        display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px;
      }
      .emoji-chip {
        font-size: 22px; padding: 4px; cursor: pointer; border-radius: 8px;
        border: 2px solid transparent; text-align: center;
        background: #fff;
      }
      .emoji-chip:hover { background: rgba(166,181,165,0.15); }
      .emoji-chip.active { border-color: ${THEME.accent}; }

      /* 描画SVGの線 */
      .draw-shape { fill: none; stroke-linecap: round; stroke-linejoin: round; }
      .draw-text {
        font-family: 'M PLUS Rounded 1c', sans-serif;
        font-weight: 900; pointer-events: auto;
      }
      .text-editor {
        position: fixed; background: transparent; border: 2px dashed ${THEME.accent};
        font-family: 'M PLUS Rounded 1c', sans-serif; font-weight: 900;
        outline: none; padding: 2px 6px; pointer-events: auto;
        z-index: 2147483647; min-width: 80px;
      }

      /* ピコーン エフェクト */
      .pikon {
        position: fixed; pointer-events: none; z-index: 2147483644;
        animation: pikonFade 0.7s ease-out forwards;
      }
      @keyframes pikonFade {
        0% { transform: translate(-50%,-50%) scale(0.3); opacity: 1; }
        60% { transform: translate(-50%,-50%) scale(1.2); opacity: 1; }
        100% { transform: translate(-50%,-50%) scale(1.5); opacity: 0; }
      }

      /* ステップ番号 */
      .step-badge {
        position: fixed; transform: translate(-50%,-50%);
        width: 36px; height: 36px; border-radius: 50%;
        background: #FF6B6B; color: #fff; font-weight: 900;
        display: flex; align-items: center; justify-content: center;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        font-size: 17px; pointer-events: auto;
        animation: stepPop 0.3s ease;
      }
      @keyframes stepPop {
        from { transform: translate(-50%,-50%) scale(0.3); }
        to { transform: translate(-50%,-50%) scale(1); }
      }

      /* スタンプ配置済み */
      .placed-stamp {
        position: fixed; transform: translate(-50%,-50%);
        padding: 8px 14px; border-radius: 14px;
        font-weight: 900; font-size: 16px;
        box-shadow: 0 4px 14px rgba(0,0,0,0.18);
        pointer-events: auto; animation: stepPop 0.3s ease;
        border: 2px solid rgba(0,0,0,0.08);
      }
      .placed-emoji {
        position: fixed; transform: translate(-50%,-50%);
        font-size: 48px; pointer-events: auto;
        animation: stepPop 0.3s ease;
        text-shadow: 0 2px 6px rgba(0,0,0,0.15);
      }
    </style>

    <div id="spotlight"></div>
    <svg id="svgOverlay" xmlns="http://www.w3.org/2000/svg"></svg>
    <div id="htmlOverlay"></div>
    <div id="magnifier"><canvas width="360" height="360"></canvas></div>
    <div id="keystroke"></div>

    <div id="toolbar">
      <div id="dragHandle" title="ドラッグで移動"></div>

      <div class="tool-row">
        <button class="tool-btn active" data-tool="pointer" title="ポインター">↖</button>
      </div>
      <div class="divider"></div>

      <button class="tool-btn" data-tool="rect" title="四角">□</button>
      <button class="tool-btn" data-tool="circle" title="丸">○</button>
      <button class="tool-btn" data-tool="arrow" title="矢印">↗</button>
      <button class="tool-btn" data-tool="pen" title="ペン">✏️</button>
      <button class="tool-btn" data-tool="text" title="テキスト">T</button>
      <div class="divider"></div>

      <button class="tool-btn" data-toggle="spotlight" title="スポットライト">🔦</button>
      <button class="tool-btn" data-toggle="magnifier" title="ルーペ(ダブルクリック)">🔍</button>
      <button class="tool-btn" data-toggle="keystroke" title="キーストローク表示">⌨️</button>
      <button class="tool-btn" data-toggle="pikon" title="ピコーン エフェクト">⚡</button>
      <button class="tool-btn" data-tool="mosaic" title="モザイク">🫥</button>
      <button class="tool-btn" data-tool="step" title="ステップ番号">①</button>
      <div class="divider"></div>

      <button class="tool-btn" data-panel="colorPanel" title="色">🎨</button>
      <button class="tool-btn" data-panel="stampPanel" title="スタンプ">💬</button>
      <button class="tool-btn" data-panel="emojiPanel" title="絵文字">😀</button>
      <div class="divider"></div>

      <button class="tool-btn" data-tool="eraser" title="個別消去">🧽</button>
      <button class="tool-btn" data-action="clear" title="全消去">🗑️</button>
      <button class="tool-btn" data-action="record" title="録画">🎥</button>
      <button class="tool-btn" data-action="close" title="閉じる">✕</button>

      <!-- パネル群 -->
      <div class="panel" id="colorPanel">
        <div class="panel-title">色 / 線の太さ</div>
        <div class="swatches"></div>
        <div class="stroke-row">
          <div class="stroke-btn active" data-stroke="2"><span class="stroke-dot" style="width:4px;height:4px"></span></div>
          <div class="stroke-btn" data-stroke="4"><span class="stroke-dot" style="width:7px;height:7px"></span></div>
          <div class="stroke-btn" data-stroke="8"><span class="stroke-dot" style="width:12px;height:12px"></span></div>
          <div class="stroke-btn" data-stroke="14"><span class="stroke-dot" style="width:18px;height:18px"></span></div>
        </div>
      </div>

      <div class="panel" id="stampPanel">
        <div class="panel-title">スタンプ</div>
        <div class="stamp-list"></div>
      </div>

      <div class="panel" id="emojiPanel">
        <div class="panel-title">絵文字</div>
        <div class="emoji-list"></div>
      </div>
    </div>
  `;

  // ──────────── ツールバー操作 ────────────
  function bindToolbar() {
    toolbar.addEventListener('click', (e) => {
      const t = e.target.closest('[data-tool],[data-toggle],[data-panel],[data-action]');
      if (!t) return;
      e.stopPropagation();
      if (t.dataset.tool) setTool(t.dataset.tool);
      else if (t.dataset.toggle) toggleFeature(t.dataset.toggle);
      else if (t.dataset.panel) togglePanel(t.dataset.panel);
      else if (t.dataset.action === 'clear') clearAll();
      else if (t.dataset.action === 'record') openRecorder();
      else if (t.dataset.action === 'close') toggleToolbar();
    });

    // 線幅ボタン
    shadow.querySelectorAll('[data-stroke]').forEach(b => {
      b.addEventListener('click', () => {
        state.strokeWidth = parseInt(b.dataset.stroke);
        shadow.querySelectorAll('[data-stroke]').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
      });
    });
  }

  function setTool(tool) {
    state.tool = tool;
    shadow.querySelectorAll('[data-tool]').forEach(b => {
      b.classList.toggle('active', b.dataset.tool === tool);
    });
    host.classList.remove('drawing', 'stamping', 'erasing');
    if (['rect','circle','arrow','pen','text','mosaic'].includes(tool)) host.classList.add('drawing');
    if (['step','stamp','emoji'].includes(tool)) host.classList.add('stamping');
    if (tool === 'eraser') host.classList.add('erasing');
  }

  function toggleFeature(name) {
    const btn = shadow.querySelector(`[data-toggle="${name}"]`);
    if (name === 'spotlight') { state.spotlightOn = !state.spotlightOn; setSpotlight(state.spotlightOn); btn.classList.toggle('active', state.spotlightOn); }
    if (name === 'magnifier') { state.magnifierOn = !state.magnifierOn; setMagnifier(state.magnifierOn); btn.classList.toggle('active', state.magnifierOn); }
    if (name === 'keystroke') { state.keystrokeOn = !state.keystrokeOn; setKeystroke(state.keystrokeOn); btn.classList.toggle('active', state.keystrokeOn); }
    if (name === 'pikon')    { state.pikonOn = !state.pikonOn; btn.classList.toggle('active', state.pikonOn); }
  }

  function togglePanel(id) {
    const panel = shadow.getElementById(id);
    shadow.querySelectorAll('.panel').forEach(p => { if (p !== panel) p.classList.remove('open'); });
    panel.classList.toggle('open');
  }

  // ──────────── カラー＆スタンプUI ────────────
  function renderColorPalette() {
    const wrap = shadow.querySelector('#colorPanel .swatches');
    wrap.innerHTML = PALETTE.map(c =>
      `<div class="swatch${c === state.color ? ' active' : ''}" data-color="${c}" style="background:${c}"></div>`
    ).join('');
    wrap.addEventListener('click', (e) => {
      const sw = e.target.closest('.swatch');
      if (!sw) return;
      state.color = sw.dataset.color;
      wrap.querySelectorAll('.swatch').forEach(s => s.classList.remove('active'));
      sw.classList.add('active');
    });
  }

  function renderStampPanel() {
    const wrap = shadow.querySelector('#stampPanel .stamp-list');
    wrap.innerHTML = STAMPS.map((s, i) =>
      `<div class="stamp-chip${i === 0 ? ' active' : ''}" data-i="${i}" style="background:${s.bg};color:${s.color}">${s.label}</div>`
    ).join('');
    wrap.addEventListener('click', (e) => {
      const chip = e.target.closest('.stamp-chip');
      if (!chip) return;
      state.selectedStamp = STAMPS[parseInt(chip.dataset.i)];
      wrap.querySelectorAll('.stamp-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      setTool('stamp');
    });
  }

  function renderEmojiPanel() {
    const wrap = shadow.querySelector('#emojiPanel .emoji-list');
    wrap.innerHTML = EMOJIS.map((e, i) =>
      `<div class="emoji-chip${i === 0 ? ' active' : ''}" data-i="${i}">${e}</div>`
    ).join('');
    wrap.addEventListener('click', (e) => {
      const chip = e.target.closest('.emoji-chip');
      if (!chip) return;
      state.selectedEmoji = EMOJIS[parseInt(chip.dataset.i)];
      wrap.querySelectorAll('.emoji-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      setTool('emoji');
    });
  }

  // ──────────── 描画（SVG） ────────────
  let dragData = null;
  function bindDrawing() {
    svgOverlay.addEventListener('pointerdown', onPointerDown);
    svgOverlay.addEventListener('pointermove', onPointerMove);
    svgOverlay.addEventListener('pointerup', onPointerUp);
    svgOverlay.addEventListener('click', onSvgClick);
  }

  function svgPoint(e) { return { x: e.clientX, y: e.clientY }; }

  function onPointerDown(e) {
    const { tool } = state;
    if (!['rect','circle','arrow','pen','mosaic'].includes(tool)) return;
    const p = svgPoint(e);
    if (tool === 'pen') {
      const path = createSvg('path', { class: 'draw-shape', stroke: state.color, 'stroke-width': state.strokeWidth, d: `M${p.x} ${p.y}` });
      svgOverlay.appendChild(path);
      bindShapeForErase(path);
      dragData = { tool, el: path, points: [p] };
    } else if (tool === 'mosaic') {
      const r = createSvg('rect', { class: 'mosaic-rect', x: p.x, y: p.y, width: 0, height: 0, fill: 'rgba(0,0,0,0.0)', stroke: '#FFD93D', 'stroke-dasharray': '6 4', 'stroke-width': 2 });
      svgOverlay.appendChild(r);
      bindShapeForErase(r);
      dragData = { tool, el: r, start: p };
    } else {
      let el;
      if (tool === 'rect') el = createSvg('rect', { class: 'draw-shape', x: p.x, y: p.y, width: 0, height: 0, stroke: state.color, 'stroke-width': state.strokeWidth });
      else if (tool === 'circle') el = createSvg('ellipse', { class: 'draw-shape', cx: p.x, cy: p.y, rx: 0, ry: 0, stroke: state.color, 'stroke-width': state.strokeWidth });
      else if (tool === 'arrow') {
        ensureArrowMarker();
        el = createSvg('line', { class: 'draw-shape', x1: p.x, y1: p.y, x2: p.x, y2: p.y, stroke: state.color, 'stroke-width': state.strokeWidth, 'marker-end': `url(#arrowHead-${cssId(state.color)})` });
      }
      svgOverlay.appendChild(el);
      bindShapeForErase(el);
      dragData = { tool, el, start: p };
    }
    e.preventDefault();
  }

  function onPointerMove(e) {
    if (!dragData) return;
    const p = svgPoint(e);
    const { tool, el, start } = dragData;
    if (tool === 'pen') {
      dragData.points.push(p);
      el.setAttribute('d', el.getAttribute('d') + ` L${p.x} ${p.y}`);
    } else if (tool === 'rect' || tool === 'mosaic') {
      const x = Math.min(start.x, p.x), y = Math.min(start.y, p.y);
      el.setAttribute('x', x); el.setAttribute('y', y);
      el.setAttribute('width', Math.abs(p.x - start.x));
      el.setAttribute('height', Math.abs(p.y - start.y));
    } else if (tool === 'circle') {
      el.setAttribute('cx', (start.x + p.x) / 2);
      el.setAttribute('cy', (start.y + p.y) / 2);
      el.setAttribute('rx', Math.abs(p.x - start.x) / 2);
      el.setAttribute('ry', Math.abs(p.y - start.y) / 2);
    } else if (tool === 'arrow') {
      el.setAttribute('x2', p.x); el.setAttribute('y2', p.y);
    }
  }

  function onPointerUp(e) {
    if (!dragData) return;
    if (dragData.tool === 'mosaic') applyMosaic(dragData.el);
    dragData = null;
  }

  function onSvgClick(e) {
    const { tool } = state;
    const p = svgPoint(e);
    if (tool === 'text') createTextAt(p);
    else if (tool === 'step') addStepBadge(p);
    else if (tool === 'stamp') addPlacedStamp(p, state.selectedStamp);
    else if (tool === 'emoji') addPlacedEmoji(p, state.selectedEmoji);
  }

  function createSvg(tag, attrs) {
    const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
    for (const k in attrs) el.setAttribute(k, attrs[k]);
    return el;
  }

  function ensureArrowMarker() {
    const id = `arrowHead-${cssId(state.color)}`;
    if (shadow.getElementById(id)) return;
    let defs = svgOverlay.querySelector('defs');
    if (!defs) { defs = createSvg('defs', {}); svgOverlay.appendChild(defs); }
    const marker = createSvg('marker', { id, viewBox: '0 0 10 10', refX: 8, refY: 5, markerWidth: 6, markerHeight: 6, orient: 'auto-start-reverse' });
    const path = createSvg('path', { d: 'M 0 0 L 10 5 L 0 10 z', fill: state.color });
    marker.appendChild(path); defs.appendChild(marker);
  }
  function cssId(c) { return c.replace('#', ''); }

  function bindShapeForErase(el) {
    el.addEventListener('click', (e) => {
      if (state.tool === 'eraser') { e.stopPropagation(); el.remove(); }
    });
  }

  function createTextAt(p) {
    const input = document.createElement('input');
    input.className = 'text-editor';
    input.type = 'text';
    input.style.left = p.x + 'px'; input.style.top = (p.y - 14) + 'px';
    input.style.color = state.color; input.style.fontSize = (state.strokeWidth * 4 + 10) + 'px';
    input.style.pointerEvents = 'auto';
    htmlOverlay.appendChild(input);
    input.focus();
    input.addEventListener('blur', commit);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') input.blur(); });
    function commit() {
      const v = input.value;
      if (v) {
        const t = createSvg('text', {
          class: 'draw-text', x: p.x, y: p.y,
          fill: state.color, 'font-size': (state.strokeWidth * 4 + 10),
        });
        t.textContent = v;
        svgOverlay.appendChild(t);
        bindShapeForErase(t);
      }
      input.remove();
    }
  }

  function addStepBadge(p) {
    const div = document.createElement('div');
    div.className = 'step-badge';
    div.style.left = p.x + 'px'; div.style.top = p.y + 'px';
    div.style.background = state.color;
    div.textContent = state.stepCounter++;
    div.addEventListener('click', (e) => { if (state.tool === 'eraser') { e.stopPropagation(); div.remove(); } });
    htmlOverlay.appendChild(div);
  }

  function addPlacedStamp(p, stamp) {
    const div = document.createElement('div');
    div.className = 'placed-stamp';
    div.style.left = p.x + 'px'; div.style.top = p.y + 'px';
    div.style.background = stamp.bg; div.style.color = stamp.color;
    div.textContent = stamp.label;
    div.addEventListener('click', (e) => { if (state.tool === 'eraser') { e.stopPropagation(); div.remove(); } });
    htmlOverlay.appendChild(div);
  }

  function addPlacedEmoji(p, emoji) {
    const div = document.createElement('div');
    div.className = 'placed-emoji';
    div.style.left = p.x + 'px'; div.style.top = p.y + 'px';
    div.textContent = emoji;
    div.addEventListener('click', (e) => { if (state.tool === 'eraser') { e.stopPropagation(); div.remove(); } });
    htmlOverlay.appendChild(div);
  }

  function applyMosaic(rect) {
    // SVGの矩形をモザイク風（半透明グレー＋ぼかし背景）に置換
    rect.setAttribute('fill', 'rgba(180,180,180,0.85)');
    rect.setAttribute('stroke', 'none');
    rect.classList.add('mosaic-applied');
    rect.style.filter = 'blur(0.5px)';
  }

  function clearAll() {
    if (!confirm('描画と配置を全てクリアしますか？')) return;
    svgOverlay.innerHTML = '';
    htmlOverlay.innerHTML = '';
    state.stepCounter = 1;
  }

  // ──────────── ピコーン エフェクト ────────────
  function bindClickEffect() {
    document.addEventListener('click', (e) => {
      if (!state.enabled || !state.pikonOn) return;
      // 拡張機能のShadow DOM内クリックは除外（host要素がcomposedPathに含まれる）
      const path = e.composedPath();
      if (path.includes(host)) return;
      spawnPikon(e.clientX, e.clientY);
    }, true);
  }

  function spawnPikon(x, y) {
    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('width', '120'); svg.setAttribute('height', '120');
    svg.setAttribute('viewBox', '-60 -60 120 120');
    svg.classList.add('pikon');
    svg.style.left = x + 'px'; svg.style.top = y + 'px';
    // 8本の黄色い放射線
    const colors = ['#FFD93D', '#FFAB00', '#FF8C42'];
    for (let i = 0; i < 12; i++) {
      const angle = (i * Math.PI * 2) / 12;
      const r1 = 18, r2 = 44;
      const w = 6;
      const x1 = Math.cos(angle) * r1, y1 = Math.sin(angle) * r1;
      const x2 = Math.cos(angle) * r2, y2 = Math.sin(angle) * r2;
      const line = document.createElementNS(NS, 'line');
      line.setAttribute('x1', x1); line.setAttribute('y1', y1);
      line.setAttribute('x2', x2); line.setAttribute('y2', y2);
      line.setAttribute('stroke', colors[i % colors.length]);
      line.setAttribute('stroke-width', w);
      line.setAttribute('stroke-linecap', 'round');
      svg.appendChild(line);
    }
    htmlOverlay.appendChild(svg);
    setTimeout(() => svg.remove(), 700);
  }

  // ──────────── スポットライト ────────────
  function bindSpotlight() {
    document.addEventListener('mousemove', (e) => {
      if (!state.spotlightOn) return;
      spotlightEl.style.setProperty('--mx', e.clientX + 'px');
      spotlightEl.style.setProperty('--my', e.clientY + 'px');
    });
  }
  function setSpotlight(on) { spotlightEl.classList.toggle('on', on); }

  // ──────────── ルーペ（ダブルクリックで拡大） ────────────
  function bindMagnifier() {
    document.addEventListener('dblclick', async (e) => {
      if (!state.magnifierOn) return;
      const path = e.composedPath();
      if (path.some(n => n.id === 'toolbar' || n.classList?.contains?.('panel'))) return;
      await showMagnifierAt(e.clientX, e.clientY);
    });
  }
  async function showMagnifierAt(x, y) {
    // ダブルクリック位置に円形ルーペを表示。拡大はCSS transformでhost側を簡易拡大
    // 実画面のキャプチャは Chrome content では不可なので、対象周辺をスナップショットする代替案：
    // 単純にダブルクリック位置をズームトランスフォームで拡大表示
    magnifierEl.style.left = (x - 90) + 'px';
    magnifierEl.style.top = (y - 90) + 'px';
    const canvas = magnifierEl.querySelector('canvas');
    const ctx = canvas.getContext('2d');
    // SVGや配置物は html2canvas等が必要なので、簡易版として「丸い拡大枠＋十字マーカー」を表示
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#fffdf2';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#FFD93D';
    ctx.lineWidth = 12;
    ctx.beginPath();
    ctx.moveTo(canvas.width / 2 - 30, canvas.height / 2);
    ctx.lineTo(canvas.width / 2 + 30, canvas.height / 2);
    ctx.moveTo(canvas.width / 2, canvas.height / 2 - 30);
    ctx.lineTo(canvas.width / 2, canvas.height / 2 + 30);
    ctx.stroke();
    ctx.fillStyle = '#262724';
    ctx.font = '900 32px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('🔍 ZOOM', canvas.width / 2, canvas.height / 2 + 80);
    magnifierEl.style.display = 'block';
    clearTimeout(magnifierEl.__t);
    magnifierEl.__t = setTimeout(() => { magnifierEl.style.display = state.magnifierOn ? 'block' : 'none'; if (!state.magnifierOn) magnifierEl.style.display = 'none'; }, 2200);
  }
  function setMagnifier(on) { magnifierEl.classList.toggle('on', on); if (!on) magnifierEl.style.display = 'none'; }

  // ──────────── キーストローク表示 ────────────
  function bindKeystroke() {
    document.addEventListener('keydown', (e) => {
      if (!state.keystrokeOn) return;
      const keys = [];
      if (e.metaKey) keys.push('⌘');
      if (e.ctrlKey) keys.push('Ctrl');
      if (e.altKey) keys.push('⌥');
      if (e.shiftKey) keys.push('⇧');
      const k = e.key.length === 1 ? e.key.toUpperCase() : e.key;
      if (!['Meta','Control','Alt','Shift'].includes(e.key)) keys.push(k);
      if (keys.length === 0) return;
      showKey(keys.join(' + '));
    }, true);
  }
  function showKey(label) {
    keystrokeEl.innerHTML = '';
    const chip = document.createElement('div');
    chip.className = 'key-chip';
    chip.textContent = label;
    keystrokeEl.appendChild(chip);
    clearTimeout(keystrokeEl.__t);
    keystrokeEl.__t = setTimeout(() => { keystrokeEl.innerHTML = ''; }, 1500);
  }
  function setKeystroke(on) { keystrokeEl.classList.toggle('on', on); if (!on) keystrokeEl.innerHTML = ''; }

  // ──────────── 録画 ────────────
  // 録画はrecorder.htmlに委譲する（getDisplayMediaのuser gestureを確実に保持するため）
  function openRecorder() {
    chrome.runtime.sendMessage({ type: 'POPUP_OPEN_RECORDER' });
  }

  // ──────────── ドラッグ移動 ────────────
  function makeDraggable(target, handle) {
    let sx, sy, ox, oy, drag = false;
    handle.addEventListener('pointerdown', (e) => {
      drag = true; sx = e.clientX; sy = e.clientY;
      const r = target.getBoundingClientRect();
      ox = r.left; oy = r.top;
      handle.setPointerCapture(e.pointerId);
    });
    handle.addEventListener('pointermove', (e) => {
      if (!drag) return;
      target.style.left = (ox + e.clientX - sx) + 'px';
      target.style.top = (oy + e.clientY - sy) + 'px';
      target.style.right = 'auto';
    });
    handle.addEventListener('pointerup', () => { drag = false; });
  }
})();
