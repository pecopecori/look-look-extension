// Demo Pointer Pro — 録画専用ページ
// このページ自体がuser gestureを保持できるため、getDisplayMediaが確実に呼べる

const setupCard = document.getElementById('setupCard');
const recordingCard = document.getElementById('recordingCard');
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const useMic = document.getElementById('useMic');
const timerEl = document.getElementById('timer');
const errorBox = document.getElementById('errorBox');

let display = null;
let micStream = null;
let audioCtx = null;
let recorder = null;
let chunks = [];
let startedAt = 0;
let timerInterval = null;

startBtn.addEventListener('click', startRecording);
stopBtn.addEventListener('click', stopRecording);

async function startRecording() {
  hideError();
  startBtn.disabled = true;

  try {
    display = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: 30 },
      audio: true,
    });
  } catch (err) {
    startBtn.disabled = false;
    showError('画面共有がキャンセルされたか、許可されませんでした。');
    return;
  }

  if (useMic.checked) {
    try {
      micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (err) {
      // マイクなしでも続行
      console.warn('マイク取得失敗、システム音声のみで録音します', err);
    }
  }

  let combinedStream;
  try {
    combinedStream = mixStreams(display, micStream);
  } catch (err) {
    cleanup();
    showError('音声ミックスに失敗しました: ' + (err.message || err));
    startBtn.disabled = false;
    return;
  }

  try {
    const mime = pickSupportedMime();
    recorder = new MediaRecorder(combinedStream, mime ? { mimeType: mime } : undefined);
  } catch (err) {
    cleanup();
    showError('MediaRecorder初期化に失敗: ' + (err.message || err));
    startBtn.disabled = false;
    return;
  }

  chunks = [];
  recorder.ondataavailable = (e) => { if (e.data && e.data.size > 0) chunks.push(e.data); };
  recorder.onstop = onRecorderStop;
  recorder.onerror = (e) => {
    showError('録画エラー: ' + (e.error?.message || 'unknown'));
    cleanup();
    resetUI();
  };

  display.getVideoTracks()[0].onended = () => {
    if (recorder && recorder.state === 'recording') stopRecording();
  };

  recorder.start(1000);
  startedAt = Date.now();
  timerInterval = setInterval(updateTimer, 500);
  setupCard.classList.add('hidden');
  recordingCard.classList.remove('hidden');
}

function stopRecording() {
  if (!recorder) return;
  if (recorder.state !== 'inactive') recorder.stop();
}

function onRecorderStop() {
  const blob = new Blob(chunks, { type: recorder.mimeType || 'video/webm' });
  const url = URL.createObjectURL(blob);
  const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const ext = (recorder.mimeType || 'webm').includes('mp4') ? 'mp4' : 'webm';
  const a = document.createElement('a');
  a.href = url;
  a.download = `demo-recording-${ts}.${ext}`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  cleanup();
  // 録画後はウィンドウを閉じる
  setTimeout(() => window.close(), 600);
}

function cleanup() {
  if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
  if (display) { display.getTracks().forEach(t => t.stop()); display = null; }
  if (micStream) { micStream.getTracks().forEach(t => t.stop()); micStream = null; }
  if (audioCtx) { audioCtx.close().catch(() => {}); audioCtx = null; }
}

function resetUI() {
  recordingCard.classList.add('hidden');
  setupCard.classList.remove('hidden');
  startBtn.disabled = false;
}

function updateTimer() {
  const sec = Math.floor((Date.now() - startedAt) / 1000);
  const mm = String(Math.floor(sec / 60)).padStart(2, '0');
  const ss = String(sec % 60).padStart(2, '0');
  timerEl.textContent = `${mm}:${ss}`;
}

function mixStreams(displayStream, mic) {
  const videoTrack = displayStream.getVideoTracks()[0];
  const dispAudio = displayStream.getAudioTracks();
  const micAudio = mic ? mic.getAudioTracks() : [];

  if (dispAudio.length === 0 && micAudio.length === 0) {
    // 音声なし。動画のみ
    return new MediaStream([videoTrack]);
  }

  if (dispAudio.length > 0 && micAudio.length === 0) {
    return new MediaStream([videoTrack, ...dispAudio]);
  }

  if (dispAudio.length === 0 && micAudio.length > 0) {
    return new MediaStream([videoTrack, ...micAudio]);
  }

  // 両方ある場合のみAudioContextでミックス
  audioCtx = new AudioContext();
  const dest = audioCtx.createMediaStreamDestination();
  audioCtx.createMediaStreamSource(new MediaStream(dispAudio)).connect(dest);
  audioCtx.createMediaStreamSource(new MediaStream(micAudio)).connect(dest);
  return new MediaStream([videoTrack, ...dest.stream.getAudioTracks()]);
}

function pickSupportedMime() {
  const candidates = [
    'video/webm;codecs=vp9,opus',
    'video/webm;codecs=vp8,opus',
    'video/webm',
    'video/mp4',
  ];
  for (const m of candidates) {
    if (MediaRecorder.isTypeSupported(m)) return m;
  }
  return null;
}

function showError(msg) {
  errorBox.textContent = msg;
  errorBox.classList.remove('hidden');
}
function hideError() {
  errorBox.classList.add('hidden');
}

window.addEventListener('beforeunload', cleanup);
