// 設定画面はプレビュー専用（v0.1.0 はカスタマイズなし、機能紹介＋パレット表示のみ）

const TOOLS = [
  { icon: '↖', name: 'ポインター' },
  { icon: '□', name: '四角で囲む' },
  { icon: '○', name: '丸で囲む' },
  { icon: '↗', name: '矢印' },
  { icon: '✏️', name: 'フリーハンド' },
  { icon: 'T', name: 'テキスト注釈' },
  { icon: '🔦', name: 'スポットライト' },
  { icon: '🔍', name: 'ルーペ(ダブルクリック)' },
  { icon: '⌨️', name: 'キーストローク表示' },
  { icon: '⚡', name: 'ピコーン エフェクト' },
  { icon: '🫥', name: 'モザイク' },
  { icon: '①', name: 'ステップ番号' },
  { icon: '💬', name: 'スタンプ' },
  { icon: '😀', name: '絵文字' },
  { icon: '🎥', name: '画面+音声 録画' },
];

document.getElementById('toolGrid').innerHTML = TOOLS.map(t =>
  `<div class="tool-cell"><span class="icon">${t.icon}</span><span>${t.name}</span></div>`
).join('');

document.getElementById('palettePreview').innerHTML = (globalThis.DEMO_EXT_PALETTE || []).map(c =>
  `<div class="swatch" style="background:${c}" title="${c}"></div>`
).join('');

document.getElementById('stampPreview').innerHTML = (globalThis.DEMO_EXT_STAMPS || []).map(s =>
  `<div class="stamp" style="background:${s.bg};color:${s.color}">${s.label}</div>`
).join('');

document.getElementById('emojiPreview').innerHTML = (globalThis.DEMO_EXT_EMOJIS || []).map(e =>
  `<div class="emoji">${e}</div>`
).join('');
