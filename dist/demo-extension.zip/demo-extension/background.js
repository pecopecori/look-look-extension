// Demo Pointer Pro — service worker
// 役割: ショートカット受信、アクション受信、録画ウィンドウ起動、content.jsへメッセージ送出

chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'toggle-toolbar') {
    const tab = await getActiveTab();
    if (!tab) return;
    const ok = await sendToTab(tab.id, { type: 'TOGGLE_TOOLBAR' });
    if (!ok) notifyUnsupported();
  } else if (command === 'toggle-recording') {
    openRecorderWindow();
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  // popup を default にしているため通常ここは呼ばれないが、フォールバックとして
  const ok = await sendToTab(tab.id, { type: 'TOGGLE_TOOLBAR' });
  if (!ok) notifyUnsupported();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'POPUP_TOGGLE_TOOLBAR') {
    (async () => {
      const tab = await getActiveTab();
      if (!tab) return sendResponse({ ok: false, error: 'no-tab' });
      const ok = await sendToTab(tab.id, { type: 'TOGGLE_TOOLBAR' });
      sendResponse({ ok, error: ok ? null : 'unsupported-page' });
    })();
    return true;
  }
  if (msg?.type === 'POPUP_OPEN_RECORDER') {
    openRecorderWindow();
    sendResponse({ ok: true });
    return true;
  }
});

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function sendToTab(tabId, message) {
  try {
    await chrome.tabs.sendMessage(tabId, message);
    return true;
  } catch (_) {
    // content script未注入のページ（chrome://、Web Store、PDF viewer等）
    return false;
  }
}

function openRecorderWindow() {
  chrome.windows.create({
    url: chrome.runtime.getURL('recorder.html'),
    type: 'popup',
    width: 420,
    height: 360,
  });
}

function notifyUnsupported() {
  // ショートカットからの呼び出し時はサイレントだが、せめてバッジで知らせる
  chrome.action.setBadgeText({ text: '✕' });
  chrome.action.setBadgeBackgroundColor({ color: '#CB5457' });
  setTimeout(() => chrome.action.setBadgeText({ text: '' }), 1800);
}
