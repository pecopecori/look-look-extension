const { escapeHtml, formatDateTime } = MeetingExtUtils;

async function init() {
  await refresh();
}

async function refresh() {
  const meetings = await MeetingExtStorage.listMeetings();
  const list = document.getElementById('meetingList');
  if (!meetings.length) {
    list.innerHTML = '<p>まだミーティングはありません。</p>';
    return;
  }
  list.innerHTML = meetings.map((meeting) => `
    <article class="meeting" data-id="${escapeHtml(meeting.meetingId)}">
      <div class="meeting-head">
        <div>
          <h2>${escapeHtml(meeting.title || meeting.tabTitle || 'Untitled')}</h2>
          <div class="meeting-meta">
            ${escapeHtml(meeting.tool || 'other')} / ${escapeHtml(formatDateTime(meeting.startedAt || Date.now()))}<br>
            chunks: ${meeting.chunkCount || 0} / failed: ${meeting.failedChunkCount || 0} / tasks: ${meeting.taskCount || 0}
          </div>
        </div>
        <span class="badge">${escapeHtml(meeting.state || 'idle')}</span>
      </div>
      <div class="actions">
        <button class="btn" data-role="select">Side Panel で見る</button>
        <button class="btn" data-role="retry">再実行</button>
        <button class="btn" data-role="write">Google に書き込み</button>
      </div>
      <div class="links">
        ${meeting.transcriptDocUrl ? `<a href="${escapeHtml(meeting.transcriptDocUrl)}" target="_blank" rel="noreferrer">Transcript Doc</a>` : ''}
        ${meeting.transcriptDocUrl && meeting.minutesDocUrl ? ' / ' : ''}
        ${meeting.minutesDocUrl ? `<a href="${escapeHtml(meeting.minutesDocUrl)}" target="_blank" rel="noreferrer">Minutes Doc</a>` : ''}
      </div>
    </article>
  `).join('');

  list.querySelectorAll('.meeting').forEach((meetingEl) => {
    const meetingId = meetingEl.dataset.id;
    meetingEl.querySelector('[data-role="select"]').addEventListener('click', async () => {
      await chrome.runtime.sendMessage({ type: 'SELECT_MEETING', meetingId });
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab) {
        await chrome.runtime.sendMessage({ type: 'OPEN_SIDE_PANEL', tabId: tab.id, windowId: tab.windowId });
      }
    });
    meetingEl.querySelector('[data-role="retry"]').addEventListener('click', async () => {
      await safeRun(() => chrome.runtime.sendMessage({ type: 'RETRY_MEETING', meetingId }));
    });
    meetingEl.querySelector('[data-role="write"]').addEventListener('click', async () => {
      await safeRun(() => chrome.runtime.sendMessage({ type: 'WRITE_OUTPUTS', meetingId }));
    });
  });
}

async function safeRun(fn) {
  try {
    const result = await fn();
    if (result?.ok === false) throw new Error(result.error || '操作に失敗しました');
    await refresh();
  } catch (error) {
    alert(error.message || String(error));
  }
}

init();
