const { formatDuration, truncate } = MeetingExtUtils;
const { getSettings, getRuntimeState, getSetupIssues } = MeetingExtStorage;

let statusTimer = null;
let toastTimer = null;

async function init() {
  bindEvents();
  await refresh();
  statusTimer = setInterval(refresh, 1000);
}

function bindEvents() {
  document.getElementById('startBtn').addEventListener('click', startRecording);
  document.getElementById('stopBtn').addEventListener('click', stopRecording);
  document.getElementById('panelBtn').addEventListener('click', openPanel);
  document.getElementById('reportBtn').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'OPEN_REPORT' }));
  document.getElementById('settingsBtn').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'OPEN_SETTINGS' }));
}

async function refresh() {
  const [settings, runtime, meetings] = await Promise.all([
    getSettings(),
    getRuntimeState(),
    MeetingExtStorage.listMeetings(),
  ]);
  const issues = getSetupIssues(settings);
  const currentMeeting = runtime.activeMeetingId
    ? meetings.find((meeting) => meeting.meetingId === runtime.activeMeetingId)
    : meetings[0] || null;
  const isRecording = !!runtime.recordingLockMeetingId;

  renderStatus(currentMeeting, isRecording);
  renderIssues(issues);

  document.getElementById('startBtn').disabled = isRecording || issues.length > 0;
  document.getElementById('stopBtn').disabled = !isRecording;
}

function renderStatus(meeting, isRecording) {
  const dot = document.getElementById('statusDot');
  const label = document.getElementById('statusLabel');
  const sub = document.getElementById('statusSub');
  const title = document.getElementById('meetingTitle');
  const elapsed = document.getElementById('meetingElapsed');

  dot.className = 'status-dot';

  if (!meeting) {
    label.textContent = '待機中';
    sub.textContent = '録音を開始すると Side Panel に文字起こしが流れます。';
    title.textContent = '—';
    elapsed.textContent = '00:00:00';
    return;
  }

  title.textContent = truncate(meeting.title || meeting.tabTitle || 'Untitled', 32);
  const startedAt = meeting.startedAt ? new Date(meeting.startedAt).getTime() : 0;
  const endedAt = meeting.endedAt ? new Date(meeting.endedAt).getTime() : Date.now();
  elapsed.textContent = startedAt ? formatDuration(endedAt - startedAt) : '00:00:00';

  if (isRecording) {
    dot.classList.add('recording');
    label.textContent = '録音中';
    sub.textContent = 'offscreen document がチャンク保存を担当しています。';
  } else if ((meeting.state || '').endsWith('_failed')) {
    dot.classList.add('failed');
    label.textContent = '失敗あり';
    sub.textContent = meeting.error || meeting.state;
  } else if (meeting.state === 'done') {
    dot.classList.add('done');
    label.textContent = '完了';
    sub.textContent = 'Docs / Calendar / Sheets まで完走しました。';
  } else {
    dot.classList.add('processing');
    label.textContent = meeting.state || '処理中';
    sub.textContent = '録音停止後の文字起こし・構造化・書き込みを進行中です。';
  }
}

function renderIssues(issues) {
  const card = document.getElementById('issuesCard');
  const list = document.getElementById('issuesList');
  card.hidden = issues.length === 0;
  list.innerHTML = issues.map((issue) => `<li>${MeetingExtUtils.escapeHtml(issue)}</li>`).join('');
}

async function startRecording() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error('アクティブなタブを取得できませんでした');
    await chrome.runtime.sendMessage({
      type: 'START_RECORDING',
      tabId: tab.id,
      tabTitle: tab.title || '',
      tabUrl: tab.url || '',
      windowId: tab.windowId,
    });
    showToast('録音を開始しました');
    await refresh();
  } catch (error) {
    showToast(error.message || String(error));
  }
}

async function stopRecording() {
  try {
    await chrome.runtime.sendMessage({ type: 'STOP_RECORDING' });
    showToast('録音停止を送信しました');
    await refresh();
  } catch (error) {
    showToast(error.message || String(error));
  }
}

async function openPanel() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  await chrome.runtime.sendMessage({
    type: 'OPEN_SIDE_PANEL',
    tabId: tab.id,
    windowId: tab.windowId,
  });
}

function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2400);
}

window.addEventListener('unload', () => clearInterval(statusTimer));
init();
