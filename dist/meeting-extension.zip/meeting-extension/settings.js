const toastEl = document.getElementById('toast');
let toastTimer = null;

async function init() {
  const settings = await MeetingExtStorage.getSettings();
  document.getElementById('docsFolderId').value = settings.docsFolderId || '';
  document.getElementById('spreadsheetId').value = settings.spreadsheetId || '';
  document.getElementById('calendarId').value = settings.calendarId || 'primary';
  document.getElementById('transcriptionApiKey').value = settings.transcriptionApiKey || '';
  document.getElementById('transcriptionModel').value = settings.transcriptionModel || 'whisper-1';
  document.getElementById('anthropicApiKey').value = settings.anthropicApiKey || '';
  document.getElementById('anthropicModel').value = settings.anthropicModel || 'claude-sonnet-4-20250514';
  document.getElementById('demoMode').checked = settings.demoMode !== false;
  document.getElementById('timezone').value = settings.timezone || MeetingExtUtils.browserTz();
  document.getElementById('approvalMode').value = settings.approvalMode || 'manual';
  document.getElementById('autoOpenSidePanel').checked = settings.autoOpenSidePanel !== false;
  document.getElementById('notifyOnFailure').checked = settings.notifyOnFailure !== false;

  document.getElementById('saveBtn').addEventListener('click', save);
  document.getElementById('provisionBtn').addEventListener('click', provision);
}

async function save() {
  const current = await MeetingExtStorage.getSettings();
  await MeetingExtStorage.saveSettings({
    ...current,
    docsFolderId: document.getElementById('docsFolderId').value.trim(),
    spreadsheetId: document.getElementById('spreadsheetId').value.trim(),
    calendarId: document.getElementById('calendarId').value.trim() || 'primary',
    transcriptionApiKey: document.getElementById('transcriptionApiKey').value.trim(),
    transcriptionModel: document.getElementById('transcriptionModel').value.trim() || 'whisper-1',
    anthropicApiKey: document.getElementById('anthropicApiKey').value.trim(),
    anthropicModel: document.getElementById('anthropicModel').value.trim() || 'claude-sonnet-4-20250514',
    demoMode: document.getElementById('demoMode').checked,
    timezone: document.getElementById('timezone').value.trim() || MeetingExtUtils.browserTz(),
    approvalMode: document.getElementById('approvalMode').value,
    autoOpenSidePanel: document.getElementById('autoOpenSidePanel').checked,
    notifyOnFailure: document.getElementById('notifyOnFailure').checked,
  });
  showToast('保存しました');
}

async function provision() {
  try {
    await save();
    const result = await chrome.runtime.sendMessage({ type: 'PROVISION_GOOGLE' });
    if (!result?.ok) throw new Error(result?.error || 'Google 初期化に失敗しました');
    document.getElementById('docsFolderId').value = result.folderId || '';
    document.getElementById('spreadsheetId').value = result.spreadsheetId || '';
    document.getElementById('calendarId').value = result.calendarId || 'primary';
    await save();
    showToast('Google リソースを作成しました');
  } catch (error) {
    showToast(error.message || String(error));
  }
}

function showToast(message) {
  toastEl.textContent = message;
  toastEl.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2400);
}

init();
