importScripts('lib/utils.js', 'lib/storage.js', 'lib/idb.js');

const {
  CHUNK_MS,
  addDays,
  buildTaskEventId,
  detectMeetingTool,
  extractJson,
  formatDate,
  meetingTitleFallback,
  nowIso,
  uuid,
} = MeetingExtUtils;

const {
  getMeeting,
  getRuntimeState,
  getSettings,
  patchMeeting,
  patchRuntimeState,
  patchTask,
  replaceMeetingTasks,
  tasksByMeeting,
  upsertMeeting,
  upsertTask,
} = MeetingExtStorage;

const {
  getArtifact,
  listMeetingChunks,
  putChunk,
  saveArtifact,
} = MeetingExtDB;

const GOOGLE_SCOPES = [
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/documents',
  'https://www.googleapis.com/auth/spreadsheets',
  'https://www.googleapis.com/auth/calendar.events',
];

const chunkQueues = new Map();
const writeLocks = new Set();
const NOTIFY_ICON = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9WnHCq0AAAAASUVORK5CYII=';

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setOptions({ path: 'sidepanel.html', enabled: true }).catch(() => {});
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    switch (message?.type) {
      case 'START_RECORDING':
        sendResponse(await handleStartRecording(message));
        return;
      case 'STOP_RECORDING':
        sendResponse(await handleStopRecording());
        return;
      case 'OPEN_SIDE_PANEL':
        await chrome.sidePanel.open({ windowId: message.windowId });
        sendResponse({ ok: true });
        return;
      case 'OPEN_REPORT':
        await chrome.tabs.create({ url: chrome.runtime.getURL('report.html') });
        sendResponse({ ok: true });
        return;
      case 'OPEN_SETTINGS':
        await chrome.runtime.openOptionsPage();
        sendResponse({ ok: true });
        return;
      case 'OFFSCREEN_RECORDING_STARTED':
        await patchMeeting(message.meetingId, {
          state: 'recording',
          startedAt: message.startedAt,
          micMissing: !!message.micMissing,
        });
        sendResponse({ ok: true });
        return;
      case 'OFFSCREEN_CHUNK_READY':
        await handleChunkReady(message);
        sendResponse({ ok: true });
        return;
      case 'OFFSCREEN_RECORDING_STOPPED':
        await handleRecordingStopped(message);
        sendResponse({ ok: true });
        return;
      case 'PROVISION_GOOGLE':
        sendResponse(await provisionGoogleResources());
        return;
      case 'APPROVE_TASK':
        await patchTask(message.taskUuid, {
          status: 'approved',
          approvedAt: nowIso(),
        });
        sendResponse({ ok: true });
        return;
      case 'SKIP_TASK':
        await patchTask(message.taskUuid, {
          status: 'skipped',
        });
        sendResponse({ ok: true });
        return;
      case 'UPDATE_TASK':
        await patchTask(message.taskUuid, message.patch || {});
        sendResponse({ ok: true });
        return;
      case 'SELECT_MEETING':
        await patchRuntimeState({ selectedMeetingId: message.meetingId });
        sendResponse({ ok: true });
        return;
      case 'STRUCTURE_MEETING':
        await structureMeeting(message.meetingId, true);
        sendResponse({ ok: true });
        return;
      case 'WRITE_OUTPUTS':
        await writeOutputs(message.meetingId, true);
        sendResponse({ ok: true });
        return;
      case 'APPROVE_ALL_AND_WRITE':
        await approveAllTasks(message.meetingId);
        await writeOutputs(message.meetingId, true);
        sendResponse({ ok: true });
        return;
      case 'RETRY_MEETING':
        await retryMeeting(message.meetingId);
        sendResponse({ ok: true });
        return;
      default:
        sendResponse({ ok: false, error: 'unknown-message' });
    }
  })().catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
  return true;
});

async function handleStartRecording(message) {
  const settings = await getSettings();
  const issues = MeetingExtStorage.getSetupIssues(settings);
  if (issues.length) throw new Error(issues[0]);

  const runtime = await getRuntimeState();
  if (runtime.recordingLockMeetingId) {
    throw new Error('録音中のため開始できません');
  }

  const meetingId = uuid();
  const tool = detectMeetingTool(message.tabUrl);
  const title = meetingTitleFallback(message.tabTitle, tool);
  const meeting = {
    meetingId,
    state: 'recording',
    startedAt: nowIso(),
    endedAt: null,
    tabUrl: message.tabUrl || '',
    tabTitle: message.tabTitle || '',
    tool,
    title,
    transcriptDocId: '',
    minutesDocId: '',
    transcriptDocUrl: '',
    minutesDocUrl: '',
    ledgerRowIndex: null,
    error: '',
    pendingTranscriptions: 0,
    chunkCount: 0,
    failedChunkCount: 0,
    stopRequested: false,
    taskCount: 0,
    approvedCount: 0,
    updatedAt: nowIso(),
  };

  await upsertMeeting(meeting);
  await saveArtifact(meetingId, {
    meetingId,
    transcriptText: '',
    transcriptSegments: [],
    failedChunks: [],
    minutesJson: null,
  });
  await patchRuntimeState({
    activeMeetingId: meetingId,
    recordingLockMeetingId: meetingId,
    selectedMeetingId: meetingId,
  });

  await ensureOffscreenDocument();
  const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: message.tabId });
  await chrome.runtime.sendMessage({
    target: 'offscreen',
    type: 'START_RECORDING',
    meetingId,
    streamId,
  });

  if (settings.autoOpenSidePanel) {
    await chrome.sidePanel.open({ windowId: message.windowId }).catch(() => {});
  }

  return { ok: true, meetingId };
}

async function handleStopRecording() {
  const runtime = await getRuntimeState();
  if (!runtime.recordingLockMeetingId) {
    throw new Error('録音中ではありません');
  }
  await chrome.runtime.sendMessage({
    target: 'offscreen',
    type: 'STOP_RECORDING',
  });
  return { ok: true };
}

async function ensureOffscreenDocument() {
  const path = 'offscreen.html';
  const offscreenUrl = chrome.runtime.getURL(path);
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [offscreenUrl],
  });
  if (contexts.length > 0) return;
  await chrome.offscreen.createDocument({
    url: path,
    reasons: ['USER_MEDIA'],
    justification: 'Meeting audio recording via chrome.tabCapture and microphone',
  });
}

async function handleChunkReady(message) {
  await enqueueChunkForTranscription(message, { persist: true, incrementCount: true });
}

async function transcribeChunk(message) {
  const settings = await getSettings();
  const result = await transcribeWithOpenAI(message.blob, settings, message.mimeType);
  const artifact = (await getArtifact(message.meetingId)) || {
    meetingId: message.meetingId,
    transcriptText: '',
    transcriptSegments: [],
    failedChunks: [],
    minutesJson: null,
  };
  const prefix = `[${message.sourceLabel.toUpperCase()} ${formatDate(message.startedAt)} ${message.startedAt.slice(11, 16)}]\n`;
  const segment = {
    segmentId: uuid(),
    chunkIndex: message.chunkIndex,
    sourceLabel: message.sourceLabel,
    text: result.text.trim(),
    startedAt: message.startedAt,
    endedAt: message.endedAt,
  };
  const nextFailed = (artifact.failedChunks || []).filter((item) => item.chunkIndex !== message.chunkIndex || item.sourceLabel !== message.sourceLabel);
  await saveArtifact(message.meetingId, {
    transcriptSegments: [...(artifact.transcriptSegments || []), segment],
    transcriptText: `${artifact.transcriptText || ''}${prefix}${segment.text}\n\n`,
    failedChunks: nextFailed,
  });

  const meeting = await getMeeting(message.meetingId);
  if (!meeting) return;
  const pending = Math.max(0, (meeting.pendingTranscriptions || 1) - 1);
  await patchMeeting(message.meetingId, {
    pendingTranscriptions: pending,
    transcriptUpdatedAt: nowIso(),
  });

  if (meeting.stopRequested && pending === 0) {
    await onTranscriptionQueueDrained(message.meetingId);
  }
}

async function registerChunkFailure(message, error) {
  const artifact = (await getArtifact(message.meetingId)) || {
    meetingId: message.meetingId,
    transcriptText: '',
    transcriptSegments: [],
    failedChunks: [],
    minutesJson: null,
  };
  const failedChunks = [...(artifact.failedChunks || []), {
    chunkIndex: message.chunkIndex,
    sourceLabel: message.sourceLabel,
    startedAt: message.startedAt,
    endedAt: message.endedAt,
    reason: error.message || String(error),
  }];
  await saveArtifact(message.meetingId, { failedChunks });

  const meeting = await getMeeting(message.meetingId);
  if (!meeting) return;
  const pending = Math.max(0, (meeting.pendingTranscriptions || 1) - 1);
  await patchMeeting(message.meetingId, {
    pendingTranscriptions: pending,
    failedChunkCount: (meeting.failedChunkCount || 0) + 1,
    error: error.message || String(error),
    state: meeting.stopRequested ? 'transcribing_failed' : meeting.state,
  });
  if (meeting.stopRequested) {
    await notify('Meeting Extension', `文字起こしに失敗: ${error.message || String(error)}`);
  }
  if (meeting.stopRequested && pending === 0) {
    await onTranscriptionQueueDrained(message.meetingId);
  }
}

async function handleRecordingStopped(message) {
  const meeting = await getMeeting(message.meetingId);
  if (!meeting) return;

  await patchMeeting(message.meetingId, {
    endedAt: message.endedAt,
    stopRequested: true,
    state: 'transcribing',
  });
  await patchRuntimeState({
    recordingLockMeetingId: null,
    activeMeetingId: message.meetingId,
    selectedMeetingId: message.meetingId,
  });

  const latest = await getMeeting(message.meetingId);
  if ((latest?.pendingTranscriptions || 0) === 0) {
    await onTranscriptionQueueDrained(message.meetingId);
  }
}

async function onTranscriptionQueueDrained(meetingId) {
  const meeting = await getMeeting(meetingId);
  if (!meeting) return;
  if ((meeting.failedChunkCount || 0) > 0) {
    await patchMeeting(meetingId, {
      state: 'transcribing_failed',
    });
    await notify('Meeting Extension', '失敗チャンクがあります。Report から再実行してください。');
    return;
  }
  await structureMeeting(meetingId, false);
}

async function structureMeeting(meetingId, manualTrigger) {
  const meeting = await getMeeting(meetingId);
  if (!meeting) throw new Error('meeting not found');
  const artifact = await getArtifact(meetingId);
  if (!artifact?.transcriptText?.trim()) {
    throw new Error('文字起こしが空です');
  }

  await patchMeeting(meetingId, {
    state: 'structuring',
    error: '',
  });

  try {
    const settings = await getSettings();
    const minutesJson = await structureWithAnthropic(artifact.transcriptText, meeting, settings);
    await saveArtifact(meetingId, { minutesJson });

    const tasks = (minutesJson.tasks || []).map((task) => ({
      taskUuid: task.task_uuid || uuid(),
      meetingId,
      title: task.title || 'Untitled task',
      owner: task.owner || '',
      due: task.due || '',
      estimateMinutes: Number(task.estimate_minutes || 0) || 0,
      context: task.context || '',
      status: settings.approvalMode === 'auto' ? 'approved' : 'pending',
      calendarEventId: '',
      approvedAt: settings.approvalMode === 'auto' ? nowIso() : '',
      insertedAt: '',
      completedAt: '',
      updatedAt: nowIso(),
    }));

    await replaceMeetingTasks(meetingId, tasks);
    await patchMeeting(meetingId, {
      title: minutesJson.title || meeting.title,
      taskCount: tasks.length,
      approvedCount: settings.approvalMode === 'auto' ? tasks.length : 0,
      state: settings.approvalMode === 'auto' || tasks.length === 0 ? 'writing_docs' : 'awaiting_approval',
    });

    if (settings.approvalMode === 'auto' || tasks.length === 0 || manualTrigger === true && settings.approvalMode === 'auto') {
      await writeOutputs(meetingId, false);
    }
  } catch (error) {
    await patchMeeting(meetingId, {
      state: 'structuring_failed',
      error: error.message || String(error),
    });
    await notify('Meeting Extension', `議事録構造化に失敗: ${error.message || String(error)}`);
    throw error;
  }
}

async function approveAllTasks(meetingId) {
  const tasks = await tasksByMeeting(meetingId);
  await Promise.all(tasks.map((task) => patchTask(task.taskUuid, {
    status: task.status === 'skipped' ? 'skipped' : 'approved',
    approvedAt: task.status === 'skipped' ? task.approvedAt : nowIso(),
  })));
  const approved = (await tasksByMeeting(meetingId)).filter((task) => task.status === 'approved').length;
  await patchMeeting(meetingId, { approvedCount: approved });
}

async function writeOutputs(meetingId, manualTrigger) {
  if (writeLocks.has(meetingId)) return;
  writeLocks.add(meetingId);

  try {
    let meeting = await getMeeting(meetingId);
    let artifact = await getArtifact(meetingId);
    const settings = await getSettings();
    let tasks = await tasksByMeeting(meetingId);

    if (!artifact?.minutesJson) {
      if (manualTrigger) {
        await structureMeeting(meetingId, true);
        meeting = await getMeeting(meetingId);
        artifact = await getArtifact(meetingId);
        tasks = await tasksByMeeting(meetingId);
      } else {
        throw new Error('議事録 JSON がまだありません');
      }
    }

    if (settings.demoMode) {
      await saveArtifact(meetingId, {
        exportPayload: {
          generatedAt: nowIso(),
          mode: 'demo',
          meeting,
          minutesJson: artifact.minutesJson,
          tasks,
        },
      });
      await patchMeeting(meetingId, { state: 'done', error: '' });
      await notify('Meeting Extension', 'デモモードで議事録生成まで完了しました。');
      return;
    }

    await patchMeeting(meetingId, { state: 'writing_docs', error: '' });
    const token = await getGoogleToken();
    const ready = await ensureGoogleResources(token, settings);
    const transcriptDoc = await ensureTranscriptDoc(token, meeting, artifact, ready.folderId);
    const minutesDoc = await ensureMinutesDoc(token, meeting, artifact, ready.folderId);

    await patchMeeting(meetingId, {
      transcriptDocId: transcriptDoc.id,
      minutesDocId: minutesDoc.id,
      transcriptDocUrl: transcriptDoc.webViewLink || '',
      minutesDocUrl: minutesDoc.webViewLink || '',
      state: 'writing_calendar',
    });

    const approvedTasks = tasks.filter((task) => task.status === 'approved');
    for (const task of approvedTasks) {
      const eventId = await ensureCalendarEvent(token, ready.calendarId, task, meeting, minutesDoc.webViewLink || transcriptDoc.webViewLink || '');
      await patchTask(task.taskUuid, {
        status: 'inserted',
        calendarEventId: eventId,
        insertedAt: nowIso(),
      });
    }

    await patchMeeting(meetingId, { state: 'writing_sheets' });
    await ensureMeetingLedgerRow(token, ready.spreadsheetId, meetingId);
    await ensureTaskLedgerRows(token, ready.spreadsheetId, meetingId);
    await patchMeeting(meetingId, { state: 'done', error: '' });
    await notify('Meeting Extension', 'Docs / Calendar / Sheets への書き込みが完了しました。');
  } catch (error) {
    const meeting = await getMeeting(meetingId);
    const failedState = inferWriteFailedState(meeting?.state);
    await patchMeeting(meetingId, {
      state: failedState,
      error: error.message || String(error),
    });
    await notify('Meeting Extension', `Google 書き込みに失敗: ${error.message || String(error)}`);
    throw error;
  } finally {
    writeLocks.delete(meetingId);
  }
}

function inferWriteFailedState(state) {
  if (state === 'writing_calendar') return 'writing_calendar_failed';
  if (state === 'writing_sheets') return 'writing_sheets_failed';
  return 'writing_docs_failed';
}

async function retryMeeting(meetingId) {
  const meeting = await getMeeting(meetingId);
  if (!meeting) throw new Error('meeting not found');
  if (meeting.state === 'transcribing_failed') {
    const artifact = await getArtifact(meetingId);
    const failed = artifact?.failedChunks || [];
    const chunks = await listMeetingChunks(meetingId);
    await saveArtifact(meetingId, { failedChunks: [] });
    await patchMeeting(meetingId, { failedChunkCount: 0, state: 'transcribing', error: '' });
    for (const chunkMeta of failed) {
      const chunk = chunks.find((item) => item.chunkIndex === chunkMeta.chunkIndex && item.sourceLabel === chunkMeta.sourceLabel);
      if (chunk) await enqueueChunkForTranscription(chunk, { persist: false, incrementCount: false });
    }
    const latest = await getMeeting(meetingId);
    if ((latest?.pendingTranscriptions || 0) === 0) await onTranscriptionQueueDrained(meetingId);
    return;
  }
  if (meeting.state === 'structuring_failed') {
    await structureMeeting(meetingId, true);
    return;
  }
  if ((meeting.state || '').startsWith('writing_')) {
    await writeOutputs(meetingId, true);
  }
}

async function transcribeWithOpenAI(blob, settings, mimeType) {
  if (settings.demoMode || !settings.transcriptionApiKey) {
    return fakeTranscription(blob, mimeType);
  }

  const form = new FormData();
  form.append('file', blob, `chunk.${mimeType.includes('mp4') ? 'mp4' : 'webm'}`);
  form.append('model', settings.transcriptionModel || 'whisper-1');
  form.append('response_format', 'json');

  const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${settings.transcriptionApiKey}`,
    },
    body: form,
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`文字起こし API 失敗: ${text || response.status}`);
  }

  const json = await response.json();
  return {
    text: json.text || '',
  };
}

async function enqueueChunkForTranscription(message, options) {
  const { persist, incrementCount } = options || {};

  if (persist) {
    const chunkId = `${message.meetingId}:${message.sourceLabel}:${message.chunkIndex}`;
    await putChunk({
      id: chunkId,
      meetingId: message.meetingId,
      sourceLabel: message.sourceLabel,
      chunkIndex: message.chunkIndex,
      blob: message.blob,
      mimeType: message.mimeType,
      startedAt: message.startedAt,
      endedAt: message.endedAt,
      createdAt: nowIso(),
    });
  }

  const meeting = await getMeeting(message.meetingId);
  if (!meeting) return;

  await patchMeeting(message.meetingId, {
    chunkCount: incrementCount ? (meeting.chunkCount || 0) + 1 : meeting.chunkCount || 0,
    pendingTranscriptions: (meeting.pendingTranscriptions || 0) + 1,
    error: '',
  });

  let queue = chunkQueues.get(message.meetingId) || Promise.resolve();
  queue = queue
    .then(() => transcribeChunk(message))
    .catch(async (error) => {
      await registerChunkFailure(message, error);
    });
  const trackedQueue = queue.finally(() => {
    if (chunkQueues.get(message.meetingId) === trackedQueue) {
      chunkQueues.delete(message.meetingId);
    }
  });
  chunkQueues.set(message.meetingId, trackedQueue);
}

async function structureWithAnthropic(transcriptText, meeting, settings) {
  if (settings.demoMode || !settings.anthropicApiKey) {
    return buildHeuristicMinutes(transcriptText, meeting);
  }

  const prompt = [
    '以下の会議文字起こしから、JSON のみを返してください。',
    'キーは title, summary_paragraphs, decisions, improvements, tasks とします。',
    'tasks は配列で、各要素は task_uuid, title, owner, due, estimate_minutes, context を持たせてください。',
    'due は不明なら空文字、estimate_minutes は数値、task_uuid は UUID 形式にしてください。',
    '余計な前置き、Markdown、コードブロックは禁止です。',
    '',
    `会議タイトル候補: ${meeting.title}`,
    '',
    '文字起こし:',
    transcriptText,
  ].join('\n');

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': settings.anthropicApiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: settings.anthropicModel || 'claude-sonnet-4-20250514',
      max_tokens: 4000,
      messages: [
        {
          role: 'user',
          content: prompt,
        },
      ],
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Anthropic API 失敗: ${text || response.status}`);
  }

  const json = await response.json();
  const text = (json.content || [])
    .filter((item) => item.type === 'text')
    .map((item) => item.text)
    .join('\n');
  const parsed = extractJson(text);

  return {
    title: parsed.title || meeting.title,
    summaryParagraphs: parsed.summary_paragraphs || parsed.summaryParagraphs || [],
    decisions: parsed.decisions || [],
    improvements: parsed.improvements || [],
    tasks: Array.isArray(parsed.tasks) ? parsed.tasks : [],
  };
}

async function getGoogleToken() {
  const manifest = chrome.runtime.getManifest();
  if (!manifest.oauth2?.client_id || manifest.oauth2.client_id.startsWith('YOUR_')) {
    throw new Error('manifest.json の oauth2.client_id を設定してください');
  }
  return await new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive: true, scopes: GOOGLE_SCOPES }, (token) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else if (!token) {
        reject(new Error('Google 認証トークンの取得に失敗しました'));
      } else {
        resolve(token);
      }
    });
  });
}

async function googleJson(token, method, url, body) {
  const response = await fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || `HTTP ${response.status}`);
  }
  if (response.status === 204) return null;
  return await response.json();
}

async function provisionGoogleResources() {
  const settings = await getSettings();
  const token = await getGoogleToken();
  const ready = await ensureGoogleResources(token, settings);
  return { ok: true, ...ready };
}

async function ensureGoogleResources(token, settings) {
  let folderId = settings.docsFolderId;
  let spreadsheetId = settings.spreadsheetId;
  const calendarId = settings.calendarId || 'primary';

  if (!folderId) {
    const folder = await googleJson(token, 'POST', 'https://www.googleapis.com/drive/v3/files?fields=id,name', {
      mimeType: 'application/vnd.google-apps.folder',
      name: 'Meeting Extension',
    });
    folderId = folder.id;
  }

  if (!spreadsheetId) {
    const sheet = await googleJson(token, 'POST', 'https://sheets.googleapis.com/v4/spreadsheets', {
      properties: { title: 'Meeting Extension Ledger' },
      sheets: [
        { properties: { title: 'meetings_log' } },
        { properties: { title: 'tasks_log' } },
      ],
    });
    spreadsheetId = sheet.spreadsheetId;
    await googleJson(
      token,
      'PUT',
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent('meetings_log!A1')}?valueInputOption=RAW`,
      {
        values: [[
          'meeting_uuid',
          'date',
          'title',
          'duration',
          'tool',
          'transcript_url',
          'minutes_url',
          'task_count',
          'approved_count',
          'status',
        ]],
      }
    );
    await googleJson(
      token,
      'PUT',
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent('tasks_log!A1')}?valueInputOption=RAW`,
      {
        values: [[
          'task_uuid',
          'meeting_uuid',
          'title',
          'owner',
          'due',
          'status',
          'event_id',
          'completed_at',
        ]],
      }
    );
  }

  await MeetingExtStorage.saveSettings({
    ...settings,
    docsFolderId: folderId,
    spreadsheetId,
    calendarId,
  });
  return { folderId, spreadsheetId, calendarId };
}

async function findExistingDoc(token, meetingId, kind) {
  const q = encodeURIComponent(`appProperties has { key='meeting_uuid' and value='${meetingId}' } and appProperties has { key='doc_kind' and value='${kind}' } and trashed=false`);
  const response = await googleJson(token, 'GET', `https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id,name,webViewLink)`);
  return response.files?.[0] || null;
}

async function ensureTranscriptDoc(token, meeting, artifact, folderId) {
  const existing = await findExistingDoc(token, meeting.meetingId, 'transcript');
  if (existing) return existing;
  const created = await googleJson(token, 'POST', 'https://docs.googleapis.com/v1/documents', {
    title: `[文字起こし] ${formatDate(meeting.startedAt)} ${meeting.title}`,
  });
  await googleJson(token, 'POST', `https://docs.googleapis.com/v1/documents/${created.documentId}:batchUpdate`, {
    requests: [
      {
        insertText: {
          location: { index: 1 },
          text: artifact.transcriptText || '',
        },
      },
    ],
  });
  return await attachDriveMetadata(token, created.documentId, folderId, meeting.meetingId, 'transcript');
}

async function ensureMinutesDoc(token, meeting, artifact, folderId) {
  const existing = await findExistingDoc(token, meeting.meetingId, 'minutes');
  if (existing) return existing;
  const created = await googleJson(token, 'POST', 'https://docs.googleapis.com/v1/documents', {
    title: `[議事録] ${formatDate(meeting.startedAt)} ${meeting.title}`,
  });
  await googleJson(token, 'POST', `https://docs.googleapis.com/v1/documents/${created.documentId}:batchUpdate`, {
    requests: [
      {
        insertText: {
          location: { index: 1 },
          text: buildMinutesText(artifact.minutesJson),
        },
      },
    ],
  });
  return await attachDriveMetadata(token, created.documentId, folderId, meeting.meetingId, 'minutes');
}

async function attachDriveMetadata(token, fileId, folderId, meetingId, kind) {
  return await googleJson(
    token,
    'PATCH',
    `https://www.googleapis.com/drive/v3/files/${fileId}?addParents=${encodeURIComponent(folderId)}&fields=id,webViewLink`,
    {
      appProperties: {
        meeting_uuid: meetingId,
        doc_kind: kind,
      },
    }
  );
}

function buildMinutesText(minutesJson) {
  const sections = [];
  sections.push(minutesJson.title || 'Meeting Minutes');
  sections.push('');
  sections.push('Summary');
  sections.push(...(minutesJson.summaryParagraphs || []), '');
  sections.push('Decisions');
  if ((minutesJson.decisions || []).length) {
    minutesJson.decisions.forEach((item) => sections.push(`- ${item}`));
  } else {
    sections.push('- なし');
  }
  sections.push('', 'Improvements');
  if ((minutesJson.improvements || []).length) {
    minutesJson.improvements.forEach((item) => sections.push(`- ${item}`));
  } else {
    sections.push('- なし');
  }
  sections.push('', 'Tasks');
  if ((minutesJson.tasks || []).length) {
    minutesJson.tasks.forEach((task) => {
      sections.push(`- ${task.title} / owner: ${task.owner || '-'} / due: ${task.due || '-'} / estimate: ${task.estimate_minutes || 0}m`);
      if (task.context) sections.push(`  context: ${task.context}`);
    });
  } else {
    sections.push('- なし');
  }
  return sections.join('\n');
}

async function ensureCalendarEvent(token, calendarId, task, meeting, docUrl) {
  const eventId = buildTaskEventId(task.taskUuid);
  const dueDate = task.due ? new Date(task.due) : addDays(meeting.endedAt || nowIso(), 1);
  const startDate = formatDate(dueDate);
  const endDate = formatDate(addDays(dueDate, 1));
  const body = {
    id: eventId,
    summary: task.title,
    description: `${task.context || ''}\n\nMeeting: ${meeting.title}\n${docUrl || ''}`.trim(),
    start: { date: startDate },
    end: { date: endDate },
  };
  const response = await fetch(`https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  if (response.status === 409) return eventId;
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || `Calendar HTTP ${response.status}`);
  }
  const json = await response.json();
  return json.id || eventId;
}

async function getSheetColumnValues(token, spreadsheetId, range) {
  const result = await googleJson(token, 'GET', `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}`);
  return result.values || [];
}

async function appendSheetRow(token, spreadsheetId, range, row) {
  await googleJson(
    token,
    'POST',
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`,
    { values: [row] }
  );
}

async function ensureMeetingLedgerRow(token, spreadsheetId, meetingId) {
  const meeting = await getMeeting(meetingId);
  const values = await getSheetColumnValues(token, spreadsheetId, 'meetings_log!A:A');
  if (values.some((row) => row[0] === meetingId)) return;
  const startedAt = new Date(meeting.startedAt);
  const endedAt = new Date(meeting.endedAt || meeting.startedAt);
  const durationMs = Math.max(0, endedAt.getTime() - startedAt.getTime());
  await appendSheetRow(token, spreadsheetId, 'meetings_log!A:J', [
    meetingId,
    formatDate(meeting.startedAt),
    meeting.title,
    Math.round(durationMs / 60000),
    meeting.tool,
    meeting.transcriptDocUrl || '',
    meeting.minutesDocUrl || '',
    meeting.taskCount || 0,
    meeting.approvedCount || 0,
    meeting.state,
  ]);
}

async function ensureTaskLedgerRows(token, spreadsheetId, meetingId) {
  const rows = await getSheetColumnValues(token, spreadsheetId, 'tasks_log!A:A');
  const existing = new Set(rows.map((row) => row[0]).filter(Boolean));
  const tasks = await tasksByMeeting(meetingId);
  for (const task of tasks) {
    if (existing.has(task.taskUuid)) continue;
    await appendSheetRow(token, spreadsheetId, 'tasks_log!A:H', [
      task.taskUuid,
      task.meetingId,
      task.title,
      task.owner || '',
      task.due || '',
      task.status,
      task.calendarEventId || '',
      task.completedAt || '',
    ]);
  }
}

async function notify(title, message) {
  const settings = await getSettings();
  if (settings.notifyOnFailure === false && title === 'Meeting Extension' && message.includes('失敗')) return;
  await chrome.notifications.create({
    type: 'basic',
    iconUrl: NOTIFY_ICON,
    title,
    message,
  }).catch(() => {});
}

function fakeTranscription(blob, mimeType) {
  const sizeKb = Math.max(1, Math.round((blob?.size || 0) / 1024));
  return {
    text: [
      'デモモード文字起こしです。',
      `ファイル形式: ${mimeType || 'audio/webm'}`,
      `チャンクサイズ: 約 ${sizeKb}KB。`,
      'このテキストは録音から議事録プレビューまでの導線確認用です。',
    ].join(' '),
  };
}

function buildHeuristicMinutes(transcriptText, meeting) {
  const rawLines = String(transcriptText || '')
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean);
  const contentLines = rawLines.filter((line) => !line.startsWith('['));
  const summaryParagraphs = [];
  for (let i = 0; i < contentLines.length && summaryParagraphs.length < 3; i += 2) {
    summaryParagraphs.push(contentLines.slice(i, i + 2).join(' '));
  }
  return {
    title: meeting.title || 'Meeting Minutes',
    summaryParagraphs: summaryParagraphs.length ? summaryParagraphs : ['デモモードで生成された要約です。'],
    decisions: [
      `${meeting.title || '会議'} の内容を要約に整理した`,
      '議事録化とタスク抽出の導線を確認した',
    ],
    improvements: [
      'Google OAuth client_id を設定して本番モードへ切り替える',
      'OpenAI / Anthropic API キーを投入して実データ処理に切り替える',
    ],
    tasks: [
      {
        task_uuid: uuid(),
        title: `${meeting.title || '会議'} のフォローアップを整理する`,
        owner: '',
        due: formatDate(addDays(new Date(), 1)),
        estimate_minutes: 30,
        context: summaryParagraphs[0] || '会議内容の整理',
      },
      {
        task_uuid: uuid(),
        title: '本番モード用の設定値を揃える',
        owner: '',
        due: formatDate(addDays(new Date(), 2)),
        estimate_minutes: 20,
        context: 'OAuth client_id / OpenAI / Anthropic の設定',
      },
    ],
  };
}
